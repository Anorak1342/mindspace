# Mindspace

A responsive personal workspace starter with flashcards, quick notes, tasks, a focus timer, and a small playable browser-game library.

## Run locally
Open `index.html` in a modern browser. No build step is required.

## Publish with GitHub Pages
1. Create a new GitHub repository named `mindspace` (or another name you prefer).
2. Upload the contents of this folder, keeping `index.html`, `styles.css`, and `app.js` together.
3. In the repository, open **Settings → Pages**.
4. Under **Build and deployment**, select **Deploy from a branch**, choose `main` and `/ (root)`, then save.
5. Wait for GitHub Pages to publish the site. The URL will look like `https://YOUR-USERNAME.github.io/mindspace/`.

## Current features
- Responsive dark-mode dashboard
- Flashcard decks: create, rename, add cards, study, flip, shuffle, mark recall
- Quick notes: create and edit
- Tasks: add, complete, delete
- Focus timer with 5, 25, and 45 minute presets
- Six small games: Neon Snake, Block Party (Breakout), Reflex, Pair Up, Pulse Pong, Mini Maze
- Browser-local persistence using `localStorage`

## Important notes
- This starter saves data in the current browser on the current device. It does not synchronise between devices.
- Game progress is not currently saved.
- All included games are original small implementations for this project. External GitHub games can be added later after checking their license, dependencies, and embedding requirements.
- Google Fonts are loaded from an external service; the site still works with fallback fonts if unavailable.
