const $ = (s, root=document) => root.querySelector(s);
const $$ = (s, root=document) => [...root.querySelectorAll(s)];
const STORE = "mindspace-v1";
const defaultData = {
  decks: [
    {id:"starter",name:"Starter deck",description:"A place for your first questions.",color:"violet",cards:[{id:"c1",front:"What is active recall?",back:"Trying to retrieve information from memory rather than just rereading it."},{id:"c2",front:"What makes a good study session?",back:"A clear goal, focused practice, and short breaks."}]}
  ],
  notes:[{id:"note1",title:"A little reminder",body:"You don't need a perfect plan. Start with the next useful step.",updated:Date.now()}],
  tasks:[{id:"task1",text:"Explore my new workspace",done:false}],
  reviewed:{}
};
let data;
try { data = JSON.parse(localStorage.getItem(STORE)) || structuredClone(defaultData); } catch { data = structuredClone(defaultData); }
function save(){ localStorage.setItem(STORE,JSON.stringify(data)); renderAll(); }
function id(){ return Math.random().toString(36).slice(2,10); }
function esc(s=""){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
function toast(msg){const t=$("#toast");t.textContent=msg;t.classList.add("show");clearTimeout(toast.t);toast.t=setTimeout(()=>t.classList.remove("show"),2300);}
const viewNames={home:"Overview",flashcards:"Flashcards",notes:"Quick notes",tasks:"Tasks",games:"Game library",focus:"Focus timer",study:"Study session"};
function showView(name){$$(".view").forEach(v=>v.classList.toggle("active-view",v.id===`view-${name}`));$$(".nav-item").forEach(b=>b.classList.toggle("active",b.dataset.view===name));$("#page-crumb").textContent=viewNames[name]||name;window.scrollTo({top:0,behavior:"smooth"});if(name==="games") closeGame(false);}
$$("[data-view]").forEach(b=>b.addEventListener("click",()=>showView(b.dataset.view)));
$("#today-label").textContent=new Intl.DateTimeFormat(undefined,{weekday:"short",month:"short",day:"numeric"}).format(new Date());
function renderAll(){renderHome();renderDecks();renderNotes();renderTasks();$("#deck-count").textContent=data.decks.length;}
function renderHome(){
  $("#home-decks").innerHTML=data.decks.slice(0,3).map(d=>`<div class="mini-row"><span class="mini-dot"></span><div><strong>${esc(d.name)}</strong><small>${d.cards.length} cards</small></div><button class="mini-open" data-study="${d.id}" aria-label="Study ${esc(d.name)}">↗</button></div>`).join("")||'<div class="empty-state">Your first deck starts here.</div>';
  $("#home-tasks").innerHTML=data.tasks.slice(0,3).map(t=>`<label class="task-mini ${t.done?"done":""}"><input type="checkbox" data-task="${t.id}" ${t.done?"checked":""}><span>${esc(t.text)}</span></label>`).join("")||'<div class="empty-state">No tasks yet. Enjoy the breathing room.</div>';
  $("#home-notes").innerHTML=data.notes.slice().sort((a,b)=>b.updated-a.updated).slice(0,2).map(n=>`<div class="notes-mini"><strong>${esc(n.title)}</strong><p>${esc(n.body)}</p></div>`).join("")||'<div class="empty-state">Your scratchpad is waiting.</div>';
  $$("[data-study]").forEach(b=>b.addEventListener("click",()=>startStudy(b.dataset.study)));
  $$("[data-task]").forEach(b=>b.addEventListener("change",()=>{const t=data.tasks.find(t=>t.id===b.dataset.task);if(t){t.done=b.checked;save();}}));
}
function renderDecks(){
  $("#deck-grid").innerHTML=data.decks.map(d=>`<article class="deck-card"><div class="deck-card-top"><span class="deck-art">▤</span><button class="deck-menu" data-deck-menu="${d.id}" aria-label="Deck options">⋯</button></div><h3>${esc(d.name)}</h3><p>${esc(d.description||"Your own collection of questions.")}</p><div class="deck-card-bottom"><span>${d.cards.length} ${d.cards.length===1?"card":"cards"}</span><button data-study="${d.id}">Study deck ↗</button></div></article>`).join("")||'<div class="deck-empty"><strong>No decks yet</strong><p>Create your first deck to start learning.</p><button class="primary-button" data-action="new-deck">＋ Create a deck</button></div>';
  $$("[data-study]").forEach(b=>b.addEventListener("click",()=>startStudy(b.dataset.study)));
  $$("[data-deck-menu]").forEach(b=>b.addEventListener("click",()=>deckOptions(b.dataset.deckMenu)));
  $$("[data-action='new-deck']").forEach(b=>b.addEventListener("click",()=>openModal("deck")));
}
function renderNotes(){
  $("#notes-grid").innerHTML=data.notes.slice().sort((a,b)=>b.updated-a.updated).map(n=>`<article class="note-card"><div class="deck-card-top"><span class="deck-art" style="background:#35291e;color:#ffc878">✎</span><button class="deck-menu" data-edit-note="${n.id}" aria-label="Edit note">✎</button></div><h3>${esc(n.title)}</h3><p>${esc(n.body)}</p><span class="note-date">${new Date(n.updated).toLocaleDateString()}</span></article>`).join("")||'<div class="deck-empty"><strong>Nothing written yet</strong><p>Capture a thought before it wanders off.</p><button class="primary-button" data-action="new-note">＋ New note</button></div>';
  $$("[data-edit-note]").forEach(b=>b.addEventListener("click",()=>openModal("note",data.notes.find(n=>n.id===b.dataset.editNote))));
}
function renderTasks(){
  const done=data.tasks.filter(t=>t.done).length;$("#task-progress").textContent=`${done} of ${data.tasks.length} completed`;
  $("#tasks-list").innerHTML=data.tasks.map(t=>`<div class="task-row ${t.done?"done":""}"><input type="checkbox" data-task="${t.id}" ${t.done?"checked":""} aria-label="Complete task"><span>${esc(t.text)}</span><button data-delete-task="${t.id}" aria-label="Delete task">×</button></div>`).join("")||'<div class="empty-state">A clear list is a good place to start.</div>';
  $$("[data-task]").forEach(b=>b.addEventListener("change",()=>{const t=data.tasks.find(t=>t.id===b.dataset.task);if(t){t.done=b.checked;save();}}));
  $$("[data-delete-task]").forEach(b=>b.addEventListener("click",()=>{data.tasks=data.tasks.filter(t=>t.id!==b.dataset.deleteTask);save();}));
}
function deckOptions(deckId){const d=data.decks.find(d=>d.id===deckId);if(!d)return;const choice=prompt(`Deck: ${d.name}\nType "add" to add a card, "edit" to rename, or "delete" to remove this deck.`);if(!choice)return;if(choice.toLowerCase()==="add")openModal("card",d);else if(choice.toLowerCase()==="edit")openModal("rename",d);else if(choice.toLowerCase()==="delete"&&confirm(`Delete "${d.name}" and its cards?`)){data.decks=data.decks.filter(x=>x.id!==deckId);save();toast("Deck deleted.");}}
const modal=$("#modal"), modalBody=$("#modal-body"), modalTitle=$("#modal-title"), modalEyebrow=$("#modal-eyebrow"), modalSubmit=$("#modal-submit");
function openModal(type,item=null){
  $("#modal-form").dataset.type=type;$("#modal-form").dataset.item=item?.id||"";modalBody.innerHTML="";
  const field=(label,name,placeholder="",value="",kind="input")=>`<div class="field"><label for="f-${name}">${label}</label>${kind==="textarea"?`<textarea id="f-${name}" name="${name}" placeholder="${placeholder}">${esc(value)}</textarea>`:`<input id="f-${name}" name="${name}" placeholder="${placeholder}" value="${esc(value)}" required>`}</div>`;
  const config={
    deck:["CREATE A STUDY DECK","Create a deck","Create",field("Deck name","name","e.g. Biology basics")+field("Description (optional)","description","What's this deck for?")],
    card:["ADD TO YOUR DECK","Add a flashcard","Add card",field("Question","front","Write a question")+field("Answer","back","Write the answer","", "textarea")],
    note:["SCRATCHPAD","Write a note","Save note",field("Title","title","A thought to keep")+field("Your note","body","Write freely...","","textarea")],
    task:["ONE STEP AT A TIME","Add a task","Add task",field("Task","text","What do you want to do?")],
    rename:["EDIT YOUR DECK","Rename deck","Save changes",field("Deck name","name","Deck name",item?.name||"")+field("Description","description","Description",item?.description||"")],
    editnote:["SCRATCHPAD","Edit note","Save note",field("Title","title","Title",item?.title||"")+field("Your note","body","Write freely...",item?.body||"","textarea")]
  };
  if(type==="card"&&!item){toast("Choose a deck first.");return;}
  const c=config[type];modalEyebrow.textContent=c[0];modalTitle.textContent=c[1];modalSubmit.textContent=c[2];modalBody.innerHTML=c[3];
  if(type==="note"&&item){$("#modal-form").dataset.type="editnote";$("#modal-form").dataset.item=item.id;modalTitle.textContent="Edit note";modalBody.innerHTML=config.editnote[3];modalSubmit.textContent="Save note";}
  modal.showModal();setTimeout(()=>modalBody.querySelector("input,textarea")?.focus(),50);
}
$$("[data-action]").forEach(b=>b.addEventListener("click",()=>openModal(({ "new-deck":"deck","new-note":"note","new-task":"task"})[b.dataset.action]||"deck")));
$$(".close-modal").forEach(b=>b.addEventListener("click",()=>modal.close()));
$("#modal-form").addEventListener("submit",e=>{
  e.preventDefault();const type=e.currentTarget.dataset.type,itemId=e.currentTarget.dataset.item;const fd=new FormData(e.currentTarget);const v=Object.fromEntries(fd.entries());
  if(type==="deck"){if(!v.name.trim())return;data.decks.push({id:id(),name:v.name.trim(),description:v.description.trim(),cards:[]});toast("Your new deck is ready.");}
  if(type==="card"){const d=data.decks.find(d=>d.id===itemId);if(d&&v.front.trim()&&v.back.trim()){d.cards.push({id:id(),front:v.front.trim(),back:v.back.trim()});toast("Flashcard added.");}}
  if(type==="note"){if(v.title.trim()||v.body.trim())data.notes.push({id:id(),title:v.title.trim()||"Untitled note",body:v.body.trim(),updated:Date.now()});toast("Note saved.");}
  if(type==="editnote"){const n=data.notes.find(n=>n.id===itemId);if(n){n.title=v.title.trim()||"Untitled note";n.body=v.body.trim();n.updated=Date.now();}toast("Note updated.");}
  if(type==="task"){if(v.text.trim())data.tasks.unshift({id:id(),text:v.text.trim(),done:false});toast("Task added.");}
  if(type==="rename"){const d=data.decks.find(d=>d.id===itemId);if(d){d.name=v.name.trim()||d.name;d.description=v.description.trim();}toast("Deck updated.");}
  modal.close();save();
});
function startStudy(deckId){const d=data.decks.find(d=>d.id===deckId);if(!d)return;if(!d.cards.length){openModal("card",d);return;}study={deckId,cards:[...d.cards],index:0,flipped:false};$("#study-title").textContent=d.name;$("#study-subtitle").textContent=d.description||"Tap the card to reveal the answer.";showView("study");renderStudy();}
let study=null;
function renderStudy(){if(!study)return;const c=study.cards[study.index];$("#flashcard-front").textContent=c.front;$("#flashcard-back").textContent=c.back;$("#flashcard").classList.toggle("flipped",study.flipped);$("#study-counter").textContent=`Card ${study.index+1} of ${study.cards.length}`;const reviewed=study.cards.filter(c=>data.reviewed[c.id]).length;$("#study-percent").textContent=`${Math.round(reviewed/study.cards.length*100)}% reviewed`;$("#study-progress-fill").style.width=`${(study.index+1)/study.cards.length*100}%`;$("#study-rating").classList.toggle("hidden",!study.flipped);}
$("#flashcard").addEventListener("click",()=>{if(!study)return;study.flipped=!study.flipped;renderStudy();});
$("#study-next").addEventListener("click",()=>{if(!study)return;study.index=(study.index+1)%study.cards.length;study.flipped=false;renderStudy();});
$("#study-prev").addEventListener("click",()=>{if(!study)return;study.index=(study.index-1+study.cards.length)%study.cards.length;study.flipped=false;renderStudy();});
$("#study-shuffle").addEventListener("click",()=>{if(!study)return;study.cards.sort(()=>Math.random()-.5);study.index=0;study.flipped=false;renderStudy();toast("Deck shuffled.");});
$("#exit-study").addEventListener("click",()=>showView("flashcards"));
$$("[data-rating]").forEach(b=>b.addEventListener("click",()=>{if(!study)return;const c=study.cards[study.index];data.reviewed[c.id]=b.dataset.rating;save();study.index=(study.index+1)%study.cards.length;study.flipped=false;renderStudy();}));
$("#settings-btn").addEventListener("click",()=>{if(confirm("Clear all Mindspace data stored in this browser? This cannot be undone.")){localStorage.removeItem(STORE);data=structuredClone(defaultData);save();toast("Workspace reset.");}});
/* Game library */
const games=[
 {id:"snake",name:"Neon Snake",genre:"Arcade",tag:"CLASSIC",glyph:"〰",cover:"cover-snake",desc:"Grow longer, collect the lights, and don't cross your own path.",time:"2–5 min"},
 {id:"breakout",name:"Block Party",genre:"Arcade",tag:"ARCADE",glyph:"▦",cover:"cover-breakout",desc:"Bounce the orb, clear the blocks, and keep the rally alive.",time:"3–6 min"},
 {id:"reaction",name:"Reflex",genre:"Quick play",tag:"QUICK PLAY",glyph:"✳",cover:"cover-reaction",desc:"Test your reaction time. Wait for the signal, then tap fast.",time:"30 sec"},
 {id:"memory",name:"Pair Up",genre:"Quick play",tag:"PUZZLE",glyph:"▧",cover:"cover-memory",desc:"Find matching pairs in this little memory challenge.",time:"1–3 min"},
 {id:"pong",name:"Pulse Pong",genre:"Arcade",tag:"CLASSIC",glyph:"◒",cover:"cover-pong",desc:"A minimal neon table-tennis duel against the computer.",time:"2–4 min"},
 {id:"maze",name:"Mini Maze",genre:"Quick play",tag:"PUZZLE",glyph:"⌗",cover:"cover-maze",desc:"Find your way through a compact maze using the arrow keys.",time:"1–2 min"}
];
let activeFilter="All", activeGame=null, gameCleanup=null;
function renderGames(){const q=$("#game-search").value.toLowerCase();const list=games.filter(g=>(activeFilter==="All"||g.genre===activeFilter)&&(g.name+" "+g.desc+" "+g.genre).toLowerCase().includes(q));$("#game-grid").innerHTML=list.map(g=>`<article class="game-card"><div class="game-cover ${g.cover}"><span class="game-tag">${g.tag}</span><span class="cover-glyph">${g.glyph}</span></div><div class="game-card-body"><h3>${g.name}</h3><p>${g.desc}</p><div class="game-card-bottom"><span>${g.time}</span><button class="play-button" data-play="${g.id}">Play now ↗</button></div></div></article>`).join("")||'<div class="deck-empty">No games match that search.</div>';$$("[data-play]").forEach(b=>b.addEventListener("click",()=>launchGame(b.dataset.play)));}
$("#game-search").addEventListener("input",renderGames);$$("[data-filter]").forEach(b=>b.addEventListener("click",()=>{activeFilter=b.dataset.filter;$$("[data-filter]").forEach(x=>x.classList.toggle("selected",x===b));renderGames();}));
$("#close-game").addEventListener("click",()=>closeGame(true));
function closeGame(scroll=true){if(gameCleanup){gameCleanup();gameCleanup=null;}activeGame=null;$("#game-stage").classList.add("hidden");$("#game-grid").classList.remove("hidden");if(scroll)$("#game-stage").scrollIntoView({behavior:"smooth",block:"start"});}
function launchGame(id){closeGame(false);activeGame=id;const g=games.find(g=>g.id===id);$("#stage-title").textContent=g.name;$("#stage-content").innerHTML="";$("#game-stage").classList.remove("hidden");$("#game-stage").scrollIntoView({behavior:"smooth",block:"start"});({snake:gameSnake,breakout:gameBreakout,reaction:gameReaction,memory:gameMemory,pong:gamePong,maze:gameMaze})[id]($("#stage-content"));}
/* Tiny self-contained games */
function gameSnake(root){
 root.innerHTML='<canvas class="game-canvas" width="420" height="420" aria-label="Snake game"></canvas><div class="game-message"><strong id="snake-score">Score: 0</strong>Use arrow keys or WASD. Press Space to restart.</div><div class="game-instructions">Collect the glowing dots. Avoid walls and your own tail.</div>';
 const c=$("canvas",root),ctx=c.getContext("2d"),scoreEl=$("#snake-score",root);let snake,dir,next,food,score,over,loop;
 function reset(){snake=[{x:10,y:10},{x:9,y:10},{x:8,y:10}];dir={x:1,y:0};next={...dir};food={x:15,y:10};score=0;over=false;scoreEl.textContent="Score: 0";draw();clearInterval(loop);loop=setInterval(tick,105);}
 function placeFood(){do{food={x:Math.floor(Math.random()*21),y:Math.floor(Math.random()*21)}}while(snake.some(s=>s.x===food.x&&s.y===food.y));}
 function tick(){if(over)return;dir=next;const h={x:snake[0].x+dir.x,y:snake[0].y+dir.y};if(h.x<0||h.x>=21||h.y<0||h.y>=21||snake.some((s,i)=>i<snake.length-1&&s.x===h.x&&s.y===h.y)){over=true;draw();return;}snake.unshift(h);if(h.x===food.x&&h.y===food.y){score++;scoreEl.textContent="Score: "+score;placeFood()}else snake.pop();draw();}
 function draw(){ctx.fillStyle="#0c1220";ctx.fillRect(0,0,420,420);ctx.strokeStyle="#182238";for(let i=0;i<=420;i+=20){ctx.beginPath();ctx.moveTo(i,0);ctx.lineTo(i,420);ctx.stroke();ctx.beginPath();ctx.moveTo(0,i);ctx.lineTo(420,i);ctx.stroke();}ctx.fillStyle="#4ce0cc";ctx.shadowColor="#4ce0cc";ctx.shadowBlur=15;ctx.beginPath();ctx.arc(food.x*20+10,food.y*20+10,6,0,Math.PI*2);ctx.fill();ctx.shadowBlur=0;snake.forEach((s,i)=>{ctx.fillStyle=i===0?"#b6aaff":"#7669e8";ctx.beginPath();ctx.roundRect(s.x*20+2,s.y*20+2,16,16,5);ctx.fill()});if(over){ctx.fillStyle="#080b13cc";ctx.fillRect(0,0,420,420);ctx.fillStyle="#fff";ctx.textAlign="center";ctx.font="bold 25px sans-serif";ctx.fillText("GAME OVER",210,200);ctx.font="14px sans-serif";ctx.fillText("Press Space to try again",210,230);}}
 function key(e){const k=e.key.toLowerCase(),map={arrowup:{x:0,y:-1},w:{x:0,y:-1},arrowdown:{x:0,y:1},s:{x:0,y:1},arrowleft:{x:-1,y:0},a:{x:-1,y:0},arrowright:{x:1,y:0},d:{x:1,y:0}};if(k===" "){e.preventDefault();reset();return}if(map[k]){e.preventDefault();const d=map[k];if(d.x!==-dir.x||d.y!==-dir.y)next=d;}}
 window.addEventListener("keydown",key);reset();gameCleanup=()=>{clearInterval(loop);window.removeEventListener("keydown",key)};
}
function gameBreakout(root){
 root.innerHTML='<canvas class="game-canvas" width="480" height="360"></canvas><div class="game-message"><strong id="break-score">Score: 0</strong>Move your mouse or use ← → to move the paddle. Click to launch.</div>';
 const c=$("canvas",root),ctx=c.getContext("2d"),sEl=$("#break-score",root);let paddle={x:200},ball={x:240,y:300,vx:3,vy:-3,live:false},blocks=[],score=0,raf,keys={};
 function reset(){paddle.x=200;ball={x:240,y:300,vx:3,vy:-3,live:false};blocks=[];score=0;for(let r=0;r<4;r++)for(let col=0;col<9;col++)blocks.push({x:17+col*50,y:35+r*22,alive:true,h:r});sEl.textContent="Score: 0";}
 function frame(){ctx.fillStyle="#0c1220";ctx.fillRect(0,0,480,360);if(keys.ArrowLeft)paddle.x-=6;if(keys.ArrowRight)paddle.x+=6;paddle.x=Math.max(0,Math.min(410,paddle.x));if(ball.live){ball.x+=ball.vx;ball.y+=ball.vy;if(ball.x<7||ball.x>473)ball.vx*=-1;if(ball.y<7)ball.vy*=-1;if(ball.y>330&&ball.x>paddle.x&&ball.x<paddle.x+70){ball.vy=-Math.abs(ball.vy);ball.vx+=(ball.x-(paddle.x+35))*.035;}if(ball.y>365){reset();}blocks.forEach(b=>{if(b.alive&&ball.x>b.x&&ball.x<b.x+42&&ball.y>b.y&&ball.y<b.y+14){b.alive=false;ball.vy*=-1;score+=10;sEl.textContent="Score: "+score;}});if(blocks.every(b=>!b.alive))reset();}blocks.forEach(b=>{if(!b.alive)return;ctx.fillStyle=["#9c8cff","#6c80ef","#4bcfca","#db91ff"][b.h];ctx.shadowColor=ctx.fillStyle;ctx.shadowBlur=7;ctx.fillRect(b.x,b.y,42,13);ctx.shadowBlur=0});ctx.fillStyle="#d4ccff";ctx.fillRect(paddle.x,333,70,9);ctx.fillStyle="#4ce0cc";ctx.shadowColor="#4ce0cc";ctx.shadowBlur=12;ctx.beginPath();ctx.arc(ball.x,ball.y,6,0,Math.PI*2);ctx.fill();ctx.shadowBlur=0;raf=requestAnimationFrame(frame);}
 function key(e){if(["ArrowLeft","ArrowRight"].includes(e.key)){keys[e.key]=e.type==="keydown";e.preventDefault();}if(e.type==="keydown"&&e.key===" "){ball.live=true;e.preventDefault();}}
 function move(e){const r=c.getBoundingClientRect();paddle.x=(e.clientX-r.left)*c.width/r.width-35;}
 c.addEventListener("pointermove",move);c.addEventListener("click",()=>ball.live=true);window.addEventListener("keydown",key);window.addEventListener("keyup",key);reset();frame();gameCleanup=()=>{cancelAnimationFrame(raf);c.removeEventListener("pointermove",move);window.removeEventListener("keydown",key);window.removeEventListener("keyup",key)};
}
function gameReaction(root){
 root.innerHTML='<button class="reaction-zone" id="reaction-zone"><span class="reaction-icon">✳</span><strong>Ready?</strong><small>Tap to begin</small></button><div class="game-message" id="reaction-result">Wait for the background to turn green, then click as quickly as you can.</div>';
 const zone=$("#reaction-zone",root),result=$("#reaction-result",root);zone.style.cssText="width:min(440px,100%);height:260px;border:1px solid #2e3950;border-radius:14px;background:#172238;color:#fff;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:8px";let state="ready",timer=null,start=0,best=null;
 function reset(){clearTimeout(timer);state="ready";zone.style.background="#172238";zone.innerHTML='<span style="font-size:38px;color:#8f83ff">✳</span><strong>Ready?</strong><small>Tap to begin</small>';result.textContent="Wait for the background to turn green, then click as quickly as you can.";}
 function click(){if(state==="ready"){state="waiting";zone.style.background="#342a49";zone.innerHTML="<strong>Wait for it...</strong><small>Don't click yet</small>";timer=setTimeout(()=>{state="go";start=performance.now();zone.style.background="#17463e";zone.innerHTML='<span style="font-size:32px">⚡</span><strong>NOW!</strong><small>Click!</small>'},900+Math.random()*2600)}else if(state==="waiting"){clearTimeout(timer);state="early";zone.style.background="#542b3c";zone.innerHTML="<strong>Too early!</strong><small>Tap to try again</small>";result.textContent="False start. Patience is part of the test."}else if(state==="go"){const ms=Math.round(performance.now()-start);state="result";zone.style.background="#172238";zone.innerHTML=`<strong style="font-size:30px;color:#70e5d4">${ms} ms</strong><small>Tap to go again</small>`;best=best===null?ms:Math.min(best,ms);result.textContent=`Reaction time: ${ms} ms · Best this session: ${best} ms`}else reset();}
 zone.addEventListener("click",click);gameCleanup=()=>{clearTimeout(timer);zone.removeEventListener("click",click)};
}
function gameMemory(root){
 root.innerHTML='<div class="memory-board" id="memory-board"></div><div class="game-message" id="memory-message">Find all the matching pairs.</div><div class="game-controls"><button class="secondary-button" id="memory-reset">New game</button></div>';
 const board=$("#memory-board",root),msg=$("#memory-message",root);board.style.cssText="display:grid;grid-template-columns:repeat(4,minmax(55px,82px));gap:9px;justify-content:center";let cards=[],opened=[],matched=0,tries=0,locked=false;
 function reset(){cards=["✦","◈","☾","✿","⚡","❋","⬡","☼", "✦","◈","☾","✿","⚡","❋","⬡","☼"].sort(()=>Math.random()-.5);opened=[];matched=0;tries=0;locked=false;msg.textContent="Find all the matching pairs.";render();}
 function render(){board.innerHTML=cards.map((v,i)=>`<button data-card="${i}" style="height:76px;border-radius:10px;border:1px solid ${matchedCards.has(i)?"#2e766b":"#303851"};background:${matchedCards.has(i)?"#173a35":opened.includes(i)?"#2b254d":"#1b2233"};color:${matchedCards.has(i)?"#67e4d4":"#c4bbff"};font-size:26px">${opened.includes(i)||matchedCards.has(i)?v:"?"}</button>`).join("");$$("[data-card]",board).forEach(b=>b.addEventListener("click",()=>flip(+b.dataset.card)));}
 let matchedCards=new Set();
 function flip(i){if(locked||opened.includes(i)||matchedCards.has(i))return;opened.push(i);render();if(opened.length===2){tries++;if(cards[opened[0]]===cards[opened[1]]){matchedCards.add(opened[0]);matchedCards.add(opened[1]);matched+=2;opened=[];render();if(matched===16)msg.textContent=`Solved in ${tries} turns. Nicely done!`;else msg.textContent=`${matched/2} of 8 pairs found · ${tries} turns`;}else{locked=true;setTimeout(()=>{opened=[];locked=false;render();msg.textContent=`Keep looking · ${tries} turns`},650);}}}
 $("#memory-reset",root).addEventListener("click",()=>{matchedCards=new Set();reset()});matchedCards=new Set();reset();gameCleanup=()=>{};
}
function gamePong(root){
 root.innerHTML='<canvas class="game-canvas" width="500" height="320"></canvas><div class="game-message"><strong id="pong-score">You 0 : 0 CPU</strong>Move your mouse or use ↑ ↓ to control your paddle.</div>';
 const c=$("canvas",root),ctx=c.getContext("2d"),scoreEl=$("#pong-score",root);let player=130,cpu=130,ball={x:250,y:160,vx:4,vy:2},ps=0,cs=0,keys={},raf;
 function resetBall(dir){ball={x:250,y:160,vx:4*dir,vy:(Math.random()-.5)*5};}
 function frame(){ctx.fillStyle="#0c1220";ctx.fillRect(0,0,500,320);ctx.strokeStyle="#283148";ctx.setLineDash([6,8]);ctx.beginPath();ctx.moveTo(250,0);ctx.lineTo(250,320);ctx.stroke();ctx.setLineDash([]);if(keys.ArrowUp)player-=5;if(keys.ArrowDown)player+=5;player=Math.max(0,Math.min(260,player));cpu+=(ball.y-40-cpu)*.045;cpu=Math.max(0,Math.min(260,cpu));ball.x+=ball.vx;ball.y+=ball.vy;if(ball.y<7||ball.y>313)ball.vy*=-1;if(ball.x<32&&ball.y>player&&ball.y<player+60){ball.vx=Math.abs(ball.vx)*1.03;ball.vy+=(ball.y-player-30)*.07;}if(ball.x>468&&ball.y>cpu&&ball.y<cpu+60){ball.vx=-Math.abs(ball.vx)*1.03;ball.vy+=(ball.y-cpu-30)*.07;}if(ball.x<0){cs++;resetBall(1)}if(ball.x>500){ps++;resetBall(-1)}ctx.fillStyle="#9b8cff";ctx.fillRect(18,player,9,60);ctx.fillStyle="#4ce0cc";ctx.fillRect(473,cpu,9,60);ctx.fillStyle="#e8e5ff";ctx.shadowColor="#8b7cff";ctx.shadowBlur=12;ctx.beginPath();ctx.arc(ball.x,ball.y,7,0,Math.PI*2);ctx.fill();ctx.shadowBlur=0;scoreEl.textContent=`You ${ps} : ${cs} CPU`;raf=requestAnimationFrame(frame);}
 function key(e){if(e.key==="ArrowUp"||e.key==="ArrowDown"){keys[e.key]=e.type==="keydown";e.preventDefault();}}
 function move(e){const r=c.getBoundingClientRect();player=(e.clientY-r.top)*c.height/r.height-30;}
 c.addEventListener("pointermove",move);window.addEventListener("keydown",key);window.addEventListener("keyup",key);frame();gameCleanup=()=>{cancelAnimationFrame(raf);c.removeEventListener("pointermove",move);window.removeEventListener("keydown",key);window.removeEventListener("keyup",key)};
}
function gameMaze(root){
 const maze=["###############","#S#.....#.....#","#.#.###.#.###.#","#...#...#...#.#","###.#.#####.#.#","#...#.....#...#","#.#####.#.###.#","#.....#.#.....#","#.###.#.#####.#","#...#...#....E#","###############"];
 root.innerHTML='<canvas class="game-canvas" width="450" height="330"></canvas><div class="game-message" id="maze-message">Use the arrow keys to find the exit.</div><div class="game-controls"><button class="secondary-button" id="maze-reset">Restart maze</button></div>';
 const c=$("canvas",root),ctx=c.getContext("2d"),msg=$("#maze-message",root);let player={x:1,y:1},end={x:13,y:9},raf;
 function draw(){ctx.fillStyle="#0c1220";ctx.fillRect(0,0,450,330);const cw=30,ch=30;maze.forEach((row,y)=>[...row].forEach((v,x)=>{if(v==="#"){ctx.fillStyle="#252746";ctx.fillRect(x*cw,y*ch,cw-1,ch-1)}else if(v==="E"){ctx.fillStyle="#4ce0cc";ctx.fillRect(x*cw+5,y*ch+5,20,20)}}));ctx.fillStyle="#a99bff";ctx.shadowColor="#8b7cff";ctx.shadowBlur=10;ctx.beginPath();ctx.arc(player.x*cw+15,player.y*ch+15,9,0,Math.PI*2);ctx.fill();ctx.shadowBlur=0;}
 function key(e){const dirs={ArrowUp:[0,-1],ArrowDown:[0,1],ArrowLeft:[-1,0],ArrowRight:[1,0]};if(!dirs[e.key])return;e.preventDefault();const [dx,dy]=dirs[e.key],x=player.x+dx,y=player.y+dy;if(maze[y]?.[x]&&maze[y][x]!=="#"){player={x,y};if(x===end.x&&y===end.y)msg.textContent="You found the exit! Press Restart maze to play again.";draw();}}
 function reset(){player={x:1,y:1};msg.textContent="Use the arrow keys to find the exit.";draw();}
 window.addEventListener("keydown",key);$("#maze-reset",root).addEventListener("click",reset);draw();gameCleanup=()=>window.removeEventListener("keydown",key);
}
renderAll();renderGames();
